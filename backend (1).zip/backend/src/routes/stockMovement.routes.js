import express from "express";
import {
  logMovement,
  getMovements,
  reverseMovement
} from "../controllers/stockMovement.controller.js";

const router = express.Router();

// router.post("/", logMovement);
// router.get("/", getMovements);
// router.put("/reverse/:id", reverseMovement);

import { requireAuth, authorizeRoles } from "../middlewares/authMiddleware.js";

router.get("/", requireAuth, getMovements);
router.post("/", requireAuth, authorizeRoles("admin", "manager"), logMovement);
router.put("/reverse/:id", requireAuth, authorizeRoles("admin"), reverseMovement);

export default router;
